export class TaskEntity {
    TaskID:number;
    ParentId :number;
    Task1:string;
    StartDate :string;
    EndDate: string;
    Priority : number;
    IsTaskEended:string;
}

